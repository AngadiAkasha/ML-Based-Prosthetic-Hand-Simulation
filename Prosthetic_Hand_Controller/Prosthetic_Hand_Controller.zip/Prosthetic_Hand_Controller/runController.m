function runController()
%RUNCONTROLLER  End-to-end PID position controller driven by the
%Random-Forest classifier's predictions on Ninapro DB1.
%
%   Pipeline:
%     PredictionResults_RF.mat (predictedLabel, from testRandomForest.m,
%     Random Forest trained/tested on Ninapro DB1, 24 classes)
%       -> label_to_angle.m                  (desired finger-angle setpoints)
%       -> GA-tuned PID + plant_modeling.m    (closed-loop position control)
%       -> ControllerResults.mat              (consumed by visualizeRandomForest.m)
%
%   Run setup_prosthetic_controller.m first so PIDGains.mat exists (GA
%   tuning); otherwise this falls back to Ziegler-Nichols tuning on the fly.

    clc;
    fprintf('=== Prosthetic Hand Controller: Ninapro DB1 ===\n\n');

    %% 1) Load the Random Forest's predictions on Ninapro DB1 -----------
    predFile = fullfile('Random_forests','PredictionResults_RF.mat');
    if ~isfile(predFile)
        predFile = 'PredictionResults_RF.mat';
    end

    if isfile(predFile)
        S = load(predFile);
        predictedLabel = double(S.predictedLabel(:));
        fprintf('Loaded %d Random Forest predictions from %s\n', ...
            numel(predictedLabel), predFile);
    else
        warning(['PredictionResults_RF.mat not found on the path. ', ...
                 'Falling back to a synthetic random DB1 label sequence ', ...
                 '(see generateSyntheticDB1Labels.m). Run testRandomForest.m ', ...
                 'first to drive the controller with real predictions.']);
        predictedLabel = generateSyntheticDB1Labels(24, 3000, 1);
    end

    N = numel(predictedLabel);
    fprintf('%d classes present: [%s]\n\n', numel(unique(predictedLabel)), ...
        num2str(unique(predictedLabel)'));

%% 2) Timing ----------------------------------------------------------
    dtOriginal = 0.2;
    replicateFactor = 4;
    dt = dtOriginal / replicateFactor;

    Nrep = N * replicateFactor;
    t = (0:Nrep-1)' * dt;

    %% 3) Desired trajectory: label -> 5-finger angle setpoints ----------
    predictedLabel = repelem(predictedLabel, replicateFactor);

    desiredAngleHistory = zeros(Nrep, 5);
    for k = 1:Nrep
        desiredAngleHistory(k,:) = label_to_angle(predictedLabel(k));
    end

    % Linear ramp between consecutive setpoints for smoother PID tracking.
    for f = 1:5
        desiredAngleHistory(:,f) = interp1(1:replicateFactor:Nrep, ...
            desiredAngleHistory(1:replicateFactor:Nrep, f), ...
            1:Nrep, 'linear', 'extrap');
    end

    N = Nrep;
    %% 4) Closed-loop plant + controller ----------------------------------
    G_plant = plant_modeling();

    gainsFile = 'PIDGains.mat';
    if isfile(gainsFile)
        G  = load(gainsFile);
        Kp = G.Kp; Ki = G.Ki; Kd = G.Kd;
        fprintf('Using GA-tuned gains from %s (Kp=%.4g  Ki=%.4g  Kd=%.4g)\n', ...
            gainsFile, Kp, Ki, Kd);
    else
        warning(['PIDGains.mat not found - tuning with Ziegler-Nichols ', ...
                 'instead. Run setup_prosthetic_controller.m for the ', ...
                 'GA-tuned gains the paper found superior.']);
        [Kp,Ki,Kd] = tune_zn(G_plant);
    end

    C   = pid(Kp,Ki,Kd);
    Tcl = minreal(feedback(C*G_plant,1));      % setpoint -> finger angle

    %% 5) Simulate every finger channel through the SAME closed-loop -----
    % dynamics (all five fingers share an identical FAULHABER motor,
    % per the paper's Section II-A).
    fingerNames = {'Thumb','Index','Middle','Ring','Little'};
    actualAngleHistory = zeros(N,5);
    for f = 1:5
        actualAngleHistory(:,f) = lsim(Tcl, desiredAngleHistory(:,f), t);
        fprintf('  %-7s finger simulated.\n', fingerNames{f});
    end

    %% 6) Save results in the format visualizeRandomForest.m expects -----
    save('ControllerResults.mat', ...
        'actualAngleHistory','desiredAngleHistory','predictedLabel','dt','t', ...
        'Kp','Ki','Kd');

    fprintf('\nControllerResults.mat saved: %d frames, dt=%.2fs, total=%.1fs\n', ...
        N, dt, N*dt);
    fprintf('Run visualizeRandomForest.m next to view the 3-D hand.\n');
end
